function myFunction() {

    var x = document.getElementById("num1").innerHTML,

          y = document.getElementById("num2").innerHTML,

          z = x * y;



   console.log(z)
    
}




